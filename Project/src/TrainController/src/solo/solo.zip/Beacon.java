public class Beacon {

    String stationName;
    int distanceToStationEnd;

    public Beacon(String stationName, int distanceToStationEnd) {
        this.stationName = stationName;
        this.distanceToStationEnd = distanceToStationEnd;
    }

}