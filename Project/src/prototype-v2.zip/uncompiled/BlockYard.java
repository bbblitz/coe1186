
public class BlockYard {
	public BlockInterface head;
	public BlockPart headto;

	//The x offset from some origin
	public int x;

	//The y offset from some origin
	public int y;
}
