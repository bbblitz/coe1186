
public enum BlockPart{
  SEC_HEAD,
  SEC_TAIL,
  SEC_DIVERGENT,
}
